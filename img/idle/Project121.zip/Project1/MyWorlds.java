import mayflower.*;
public class MyWorlds extends World
{ 
  

    public MyWorlds()
    {
        
    }
    public void act(){
    }
    
}
