import mayflower.*;
public class Project1Runner
{



  public static void main(String[] args){
    
    new MyMayflower();
    }


}
