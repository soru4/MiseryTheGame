import mayflower.*;
public class PoorMiner extends Actor
{
    public MoveState moveState = MoveState.NONE;
    public MoveState dir = MoveState.RIGHT;
    public int jumpForce; 
    public PoorMiner()
    {
        // this is the class for the poor child miner 
        // this game will attempt to bring aawarness to child labourers. 
        jumpForce = 2; 
    }
    public void act(){
        
        int x = getX();
        int y = getY();
        int w = getWidth();
        int h = getHeight();
        if (Mayflower.isKeyDown( Keyboard.KEY_RIGHT )) {
            dir = MoveState.RIGHT;
           moveState = MoveState.RIGHT;
           setLocation(x + 1, y);
        }
        if (Mayflower.isKeyDown( Keyboard.KEY_LEFT )) {
            moveState = MoveState.LEFT;
            dir = MoveState.LEFT;
           setLocation(x - 1, y);
        }
        
        if(Mayflower.isKeyDown( Keyboard.KEY_UP)){
            if(dir == MoveState.LEFT)
                moveState = MoveState.JUMPL;
            if(dir == MoveState.RIGHT)
                moveState = MoveState.JUMPR;
            
            
            setLocation(x , y - 50);
            // set Animation 
            
        }
    }
    
 
    public enum MoveState{
        LEFT,
        RIGHT,
        JUMPR,
        JUMPL,
        NONE
        
    }
}
